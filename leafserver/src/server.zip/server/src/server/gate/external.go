package gate

import (
	"server/gate/internal"
)

var (
	Module = new(internal.Module)
)
